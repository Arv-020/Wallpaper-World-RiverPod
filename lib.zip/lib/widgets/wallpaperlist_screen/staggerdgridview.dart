import 'package:flutter/material.dart';
import 'package:wallpaper_world/screens/wallpaperscreen.dart';

class CustomStaggeredGridView extends StatelessWidget {
  const CustomStaggeredGridView({super.key, required this.img});
  final List<String> img;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 9 / 16,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16),
        itemCount: img.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => WallpaperScreen(img: img[index]),
                ),
              );
            },
            child: Container(
              // width: MediaQuery.sizeOf(context).width * .39,

              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(img[index]),
                  )),
            ),
          );
        });
  }
}
