class WallpaperModel {
  WallpaperModel({required this.category, required this.img});
  final String category;
  final List<String> img;
}
